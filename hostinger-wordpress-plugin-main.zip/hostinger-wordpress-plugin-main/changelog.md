Changelog
=========
1.2.0 (2023-03-22)
- Updated How To videos
- Added Lithuanian language translations
- Updated assets

1.3.0 (2023-04-11)
- Autocomplete onboarding steps
- Redirect Hosting clients by segment
- Hide logo upload step if theme not support
- Updated How To videos
- Updated translations
- Updated onboarding steps

1.4.0 (2023-04-17)
- Added new "Add product" step
- Adjusted onboarding steps by website type
- Updated logo upload step
- Autocomplete site title step on settings change

1.4.1 (2023-05-15)
- Fix site health session warning

1.5.0 (2023-05-23)
- Add onboarding steps autocomplete date

1.6.0 (2023-06-08)
- Add plugin update feature

1.6.1 (2023-06-13)
- Fixed unused assets
- Fixed maintenance mode cache

1.6.2 (2023-06-15)
- Fixed maintenance mode conflicts with other plugins
- 
1.6.3 (2023-07-11)
- Add AI assistant

1.6.5 (2023-08-14)
- Add translations

1.6.6 (2023-08-17)
- Add additional submenu items

1.6.7 (2023-09-08)
- Bugfixes
- Redirect all users from hpanel
- Text changes

1.7.0 (2023-09-08)
- Add CSAT survey

1.7.1 (2023-09-20)
- Add additional request header

1.7.2 (2023-09-22)
- Hide notices in hostinger page

1.8.0 (2023-09-27)
- Additional amplitude events

1.8.1 (2023-10-03)
- Remove video iframes

1.8.2 (2023-10-05)
- Adjust CSAT survey

1.8.3 (2023-10-13)
- Add domain connection step
- Hide preview banner

1.8.4 (2023-10-20)
- Added regenerate website tab
- Style corrections

1.8.5 (2023-10-20)
- Text corrections

1.8.6 (2023-10-23)
- Translations

1.8.7 (2023-10-30)
- Add woocommerce onboarding survey

1.8.8 (2023-11-13)
- Bugfixes

1.8.9 (2023-11-14)
- Added onboarding survey
- Fix onboarding steps duplicates

1.9.0 (2023-11-15)
- Fix survey transients

1.9.1 (2023-11-15)
- Add translations

1.9.2 (2023-11-19)
- Fixes

1.9.3 (2023-11-21)
- Fixed RTL survey issues
- Added survey close button

1.9.4 (2023-11-23)
- Fix survey requests

1.9.5 (2023-11-27)
- Hide notices in hostinger page
- Remove surveys

1.9.6 (2023-12-01)
- Added filter for tabs / tab content

1.9.7 (2023-12-13)
- Added tests, adjusted assets loading
- Fixed maintenance security issue

1.9.8 (2023-12-14)
- Version mismatch fix

1.9.9 (2023-12-18)
- Fixed assets load on subfolder installations

2.0.1 (2024-01-16)
- Added onboarding step for affiliate plugin

2.0.2 (2024-01-19)
- Updated internal services

2.0.3 (2024-01-19)
- Fixes
- Added promotional banner

2.0.4 (2024-02-02)
- Added jump to hpanel
- Redesign tabs section

2.0.5 (2024-02-06)
- Added surveys
