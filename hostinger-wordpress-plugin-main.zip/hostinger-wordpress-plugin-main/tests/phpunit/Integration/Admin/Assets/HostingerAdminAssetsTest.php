<?php

namespace Hostinger\Tests\Integration\Admin\Assets;
use _WP_Dependency;
use Hostinger\Tests\Integration\TestCase;
use Hostinger_Admin_Assets;

/**
 * Class HostingerAdminAssetsTest
 *
 * Integration tests for the Hostinger_Admin_Assets class.
 */
class HostingerAdminAssetsTest extends TestCase {

	/**
	 * Set up method for test initialization.
	 */
	public function set_up(): void {
		parent::set_up();
		require_once HOSTINGER_ABSPATH . 'includes/admin/class-hostinger-admin-assets.php';
	}

	/**
	 * Test loaded assets on the Hostinger admin page.
	 */
	public function test_loaded_assets_on_hostinger_page(): void {
		$this->check_loaded_assets_on_page('/wp-admin/admin.php?page=hostinger');
	}

	/**
	 * Test loaded assets on the Hostinger admin page in subfolder.
	 */
	public function test_loaded_assets_on_hostinger_subfolder_page(): void {
		$this->check_loaded_assets_on_page('subfolder/wp-admin/admin.php?page=hostinger');
	}

	/**
	 * Test that assets are not loaded on other pages.
	 */
	public function test_not_loaded_assets_on_other_pages(): void {
		$this->go_to('/wp-admin/admin.php');
		$hostinger_admin_assets = new Hostinger_Admin_Assets();
		$hostinger_admin_assets->admin_scripts();
		$hostinger_admin_assets->admin_styles();
		$utilsStyle = wp_scripts()->query('utils');
		$mainScripts = wp_scripts()->query('hostinger_main_scripts', 'enqueued');
		$mainStyles = wp_styles()->query('hostinger_main_styles', 'enqueued');

		$this->assertEquals('utils', $utilsStyle->handle);
		$this->assertFalse($mainScripts);
		$this->assertFalse($mainStyles);
	}

	/**
	 * Common method to check loaded assets on a specific page.
	 *
	 * @param string $page_url The URL of the page to check.
	 */
	private function check_loaded_assets_on_page(string $page_url): void {
		$this->go_to($page_url);
		$hostinger_admin_assets = new Hostinger_Admin_Assets();
		$hostinger_admin_assets->admin_scripts();
		$hostinger_admin_assets->admin_styles();

		$this->assertTrue(wp_script_is('hostinger_main_scripts'));
		$this->assertTrue(wp_style_is('hostinger_main_styles'));

		wp_dequeue_script('hostinger_main_scripts');
		wp_dequeue_style('hostinger_main_styles');
	}
}
