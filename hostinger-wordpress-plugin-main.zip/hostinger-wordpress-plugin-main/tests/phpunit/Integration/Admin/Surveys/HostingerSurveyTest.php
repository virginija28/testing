<?php

namespace Hostinger\Tests\Integration\Admin\Surveys;


use Hostinger\Tests\Integration\TestCase;
use Hostinger_Settings;
use Hostinger_Helper;
use Hostinger_Config;
use Hostinger_Surveys;
use Hostinger_Surveys_Questions;
use Hostinger_Surveys_Rest;

class HostingerSurveyTest extends TestCase {

	private Hostinger_Config $config_handler;
	private Hostinger_Settings $settings;
	private Hostinger_Helper $helper;
	private Hostinger_Surveys_Questions $survey_questions;
	private Hostinger_Surveys_Rest $surveys_rest;
	private Hostinger_Surveys $surveys;

	public function setUp(): void {
		parent::setUp();
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-settings.php';
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-helper.php';
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-config.php';
		require_once HOSTINGER_ABSPATH . 'includes/surveys/Rest/class-hostinger-surveys-rest.php';
		require_once HOSTINGER_ABSPATH . 'includes/surveys/class-hostinger-surveys.php';
		require_once HOSTINGER_ABSPATH . 'includes/surveys/class-hostinger-surveys-questions.php';


		$this->settings         = new Hostinger_Settings();
		$this->helper           = new Hostinger_Helper();
		$this->config_handler   = new Hostinger_Config();
		$this->survey_questions = new Hostinger_Surveys_Questions();

		$this->surveys_rest = $this->createMock( Hostinger_Surveys_Rest::class );
		$this->helper       = $this->createMock( Hostinger_Helper::class );
		$this->surveys      = $this->getMockBuilder( Hostinger_Surveys::class )->setConstructorArgs(
			[
				$this->settings,
				$this->helper,
				$this->config_handler,
				$this->survey_questions,
				$this->surveys_rest
			]
		)->onlyMethods( [
			'is_woocommerce_admin_page',
			'is_client_eligible',
			'get_survey_questions',
			'default_woocommerce_survey_completed',
		] )->getMock();

	}

	public function testIsNotWooCommerceAdminPage() {
		$surveys = new Hostinger_Surveys( $this->settings, $this->helper, $this->config_handler, $this->survey_questions, $this->surveys_rest );
		// Test when current URI does not match any WooCommerce page
		$this->go_to('/wp-admin/index.php');
		$this->assertFalse( $surveys->is_woocommerce_admin_page() );
	}

	public function testIsWooCommerceAdminPage() {
		$surveys = new Hostinger_Surveys(
			$this->settings,
			$this->helper,
			$this->config_handler,
			$this->survey_questions,
			$this->surveys_rest
		);

		foreach ( $surveys::WOOCOMMERCE_PAGES as $page ) {
			$this->go_to($page);
			$this->assertTrue( $surveys->is_woocommerce_admin_page() );
		}

	}

	public function testIsSurveyEnabledWhenEnabled() {
		$this->helper->method( 'is_hostinger_admin_page' )->willReturn( true );
		$survey = $this->getMockBuilder( Hostinger_Surveys::class )->setConstructorArgs(
			[
				$this->settings,
				$this->helper,
				$this->config_handler,
				$this->survey_questions,
				$this->surveys_rest
			]
		)->onlyMethods( [
			'is_woocommerce_admin_page',
			'is_client_eligible',
			'get_survey_questions',
			'default_woocommerce_survey_completed',
			'is_ai_onboarding_survey_enabled',

		] )->getMock();
		$survey->method( 'get_survey_questions' )->willReturn( [ 'test' => 'test21' ] );
		$survey->method( 'is_ai_onboarding_survey_enabled' )->willReturn( false );
		$survey->method( 'is_client_eligible' )->willReturn( true );

		update_option( 'hostinger_content_published', 1 );
		set_transient( 'submitted_survey_transient', false, 60 * 60 * 24 * 30 );

		$this->assertTrue( $survey->is_survey_enabled() );
	}

	/**
	 * @dataProvider invalidMainSurveyDataProvider
	 */
	public function testIsSurveyEnabledWhenDisabled( array $surveyQuestions, bool $contentPublished, bool $isAdminPage ) {
		$this->helper->method( 'is_hostinger_admin_page' )->willReturn( $isAdminPage );
		$this->surveys_rest->method( 'get_survey_questions' )->willReturn( $surveyQuestions );
		update_option( 'hostinger_content_published', $contentPublished );
		$this->assertFalse( $this->surveys->is_survey_enabled() );
	}

	public function invalidMainSurveyDataProvider(): array {
		return [
			[
				'surveyQuestions'  => [],
				'contentPublished' => true,
				'isAdminPage'      => true
			],
			[
				'surveyQuestions'  => [ 'test' => 'test21' ],
				'contentPublished' => false,
				'isAdminPage'      => true
			],
			[
				'surveyQuestions'  => [ 'test' => 'test21' ],
				'contentPublished' => true,
				'isAdminPage'      => false
			],
		];
	}

	public function testIsWoocommerceSurveyEnabledWhenEnabled() {
		update_option( 'hostinger_survey.website.type', 'shop' );
		update_option( 'hostinger_woocommerce_survey_completed', 0 );
		$this->surveys->method( 'get_survey_questions' )->willReturn( [ 'question' => 'xxx' ] );
		$this->surveys->method( 'is_woocommerce_admin_page' )->willReturn( true );
		$this->surveys->method( 'default_woocommerce_survey_completed' )->willReturn( true );
		$this->surveys->method( 'is_client_eligible' )->willReturn( true );
		$value = $this->surveys->is_woocommerce_survey_enabled();

		$this->assertTrue( $value );
	}

	/**
	 * @dataProvider invalidWooSurveyDataProvider
	 */
	public function testIsWoocommerceSurveyEnabledWhenDisabled( array $surveyQuestions, bool $woocommerceOnboardingCompleted, bool $isWooPage, string $websiteType ) {
		$this->surveys->method( 'is_woocommerce_admin_page' )->willReturn( $isWooPage );
		$this->surveys->method( 'default_woocommerce_survey_completed' )->willReturn( $woocommerceOnboardingCompleted );
		set_transient( 'submitted_survey_transient', false, 60 * 60 * 24 * 30 );
		$this->surveys->method( 'get_survey_questions' )->willReturn( $surveyQuestions );
		update_option( 'hostinger_survey.website.type', $websiteType );
		update_option( 'hostinger_woocommerce_survey_completed', 0 );

		$this->assertFalse( $this->surveys->is_woocommerce_survey_enabled() );
	}

	public function invalidWooSurveyDataProvider(): array {
		return [
			[
				'surveyQuestions'                => [],
				'woocommerceOnboardingCompleted' => true,
				'isWooPage'                      => true,
				'websiteType'                    => 'shop',
			],
			[
				'surveyQuestions'                => [ 'test' => 'test21' ],
				'woocommerceOnboardingCompleted' => false,
				'isWooPage'                      => true,
				'websiteType'                    => 'shop',
			],
			[
				'surveyQuestions'  => [ 'test' => 'test21' ],
				'contentPublished' => false,
				'isWooPage'        => false,
				'websiteType'      => 'shop',
			],
			[
				'surveyQuestions'  => [ 'test' => 'test21' ],
				'contentPublished' => true,
				'isWooPage'        => true,
				'websiteType'      => '',
			]
		];
	}

	public function testIsAiOnboardingSurveyEnabledWhenEnabled() {
		update_option( 'hostinger_ai_onboarding', true );
		$this->surveys->method( 'get_survey_questions' )->willReturn( [ 'question' => 'xxx' ] );
		$this->surveys->method( 'is_woocommerce_admin_page' )->willReturn( false );
		$this->surveys->method( 'is_client_eligible' )->willReturn( true );
		$this->helper->method( 'is_hostinger_admin_page' )->willReturn( true );

		$this->assertTrue( $this->surveys->is_ai_onboarding_survey_enabled() );
	}

	/**
	 * @dataProvider invalidAiOnboardingSurveyDataProvider
	 */
	public function testIsAiOnboardingSurveyEnabledWhenDisabled( array $surveyQuestions, bool $aiOnboardingCompleted, bool $isHostingerPage, bool $isWooPage, bool $isClientEligible ) {
		update_option( 'hostinger_ai_onboarding', $aiOnboardingCompleted );
		update_option( 'hostinger_woocommerce_survey_completed', true );
		$this->surveys->method( 'get_survey_questions' )->willReturn( $surveyQuestions );
		$this->surveys->method( 'is_woocommerce_admin_page' )->willReturn( $isWooPage );
		$this->surveys->method( 'is_client_eligible' )->willReturn( $isClientEligible );
		$this->helper->method( 'is_hostinger_admin_page' )->willReturn( $isHostingerPage );

		$this->assertFalse( $this->surveys->is_ai_onboarding_survey_enabled() );
	}

	public function invalidAiOnboardingSurveyDataProvider(): array {
		return [
			[
				'surveyQuestions'                => [],
				'woocommerceOnboardingCompleted' => true,
				'isHostingerPage'                => true,
				'isWooPage'                      => false,
				'isClientEligible'               => true,
			],
			[
				'surveyQuestions'                => [ 'test' => 'test21' ],
				'woocommerceOnboardingCompleted' => true,
				'isHostingerPage'                => false,
				'isWooPage'                      => true,
				'isClientEligible'               => false,
			],
			[
				'surveyQuestions'                => [ 'test' => 'test21' ],
				'woocommerceOnboardingCompleted' => true,
				'isHostingerPage'                => true,
				'isWooPage'                      => true,
				'isClientEligible'               => false,
			],
			[
				'surveyQuestions'                => [ 'test' => 'test21' ],
				'woocommerceOnboardingCompleted' => true,
				'isHostingerPage'                => true,
				'isWooPage'                      => false,
				'isClientEligible'               => false,
			]
		];
	}

	public function testDefaultWooCommerceSurveyCompletedWhenCompleted() {

		$survey = $this->getMockBuilder( Hostinger_Surveys::class )->setConstructorArgs(
			[
				$this->settings,
				$this->helper,
				$this->config_handler,
				$this->survey_questions,
				$this->surveys_rest
			]
		)->onlyMethods( [
			'is_woocommerce_admin_page',
			'is_client_eligible',
			'get_survey_questions',
		] )->getMock();

		$completedActions = array( 'products', 'payments' );
		update_option( 'woocommerce_task_list_tracked_completed_tasks', $completedActions );
		$this->assertTrue( $survey->default_woocommerce_survey_completed() );
	}

	/**
	 * @dataProvider wooSurveyDataProvider
	 */
	public function testDefaultWooCommerceSurveyCompletedWhenNotCompleted( array $completedTasks ) {
		$survey = $this->getMockBuilder( Hostinger_Surveys::class )->setConstructorArgs(
			[
				$this->settings,
				$this->helper,
				$this->config_handler,
				$this->survey_questions,
				$this->surveys_rest
			]
		)->onlyMethods( [
			'is_woocommerce_admin_page',
			'is_client_eligible',
			'get_survey_questions',
		] )->getMock();

		update_option( 'woocommerce_task_list_tracked_completed_tasks', $completedTasks );
		$this->assertFalse( $survey->default_woocommerce_survey_completed() );
	}

	public function wooSurveyDataProvider(): array {
		return [
			[
				'completedTasks' => [],
			],
			[
				'completedTasks' => [ 'products' ],
			],
		];
	}

	public function testIsClientEligible() {
		$survey = $this->getMockBuilder( Hostinger_Surveys::class )->setConstructorArgs(
			[
				$this->settings,
				$this->helper,
				$this->config_handler,
				$this->survey_questions,
				$this->surveys_rest
			]
		)->onlyMethods( [
			'is_woocommerce_admin_page',
			'get_survey_questions',
		] )->getMock();

		set_transient( \Hostinger_Surveys::IS_CLIENT_ELIGIBLE_TRANSIENT_RESPONSE, 'eligible' );
		set_transient( \Hostinger_Surveys::IS_CLIENT_ELIGIBLE_TRANSIENT_REQUEST, true );

		$this->assertTrue( $survey->is_client_eligible() );
	}

	/**
	 * @dataProvider clientEligibilityProvider
	 */
	public function testIsClientNotEligible( bool $transientResponse, bool $transientRequest ) {
		$survey = $this->getMockBuilder( Hostinger_Surveys::class )->setConstructorArgs(
			[
				$this->settings,
				$this->helper,
				$this->config_handler,
				$this->survey_questions,
				$this->surveys_rest
			]
		)->onlyMethods( [
			'is_woocommerce_admin_page',
			'get_survey_questions',
		] )->getMock();

		set_transient( \Hostinger_Surveys::IS_CLIENT_ELIGIBLE_TRANSIENT_RESPONSE, $transientResponse );
		set_transient( \Hostinger_Surveys::IS_CLIENT_ELIGIBLE_TRANSIENT_REQUEST, $transientRequest );

		$this->assertFalse( $survey->is_client_eligible() );
	}

	public function clientEligibilityProvider(): array {
		return [
			[ false, false ],
			[ false, true ],
		];
	}

	public function testGenerateSurveyHtml() {
		$surveys = $this->getMockBuilder( Hostinger_Surveys::class )
		                ->setConstructorArgs( [
			                $this->settings,
			                $this->helper,
			                $this->config_handler,
			                $this->survey_questions,
			                $this->surveys_rest
		                ] )
		                ->onlyMethods( [] )
		                ->getMock();

		$result = $surveys->generate_survey_html( 'custom-class' );
		$expectedHtml = preg_replace( '/\s+/', '',
		<<<HTML
			<div class="hts-survey-wrapper custom-class">
			    <div class="close-btn">
			        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="100" height="100" viewBox="0 0 24 24">
			            <path d="M 4.9902344 3.9902344 A 1.0001 1.0001 0 0 0 4.2929688 5.7070312 L 10.585938 12 L 4.2929688 18.292969 A 1.0001 1.0001 0 1 0 5.7070312 19.707031 L 12 13.414062 L 18.292969 19.707031 A 1.0001 1.0001 0 1 0 19.707031 18.292969 L 13.414062 12 L 19.707031 5.7070312 A 1.0001 1.0001 0 0 0 18.980469 3.9902344 A 1.0001 1.0001 0 0 0 18.292969 4.2929688 L 12 10.585938 L 5.7070312 4.2929688 A 1.0001 1.0001 0 0 0 4.9902344 3.9902344 z"></path>
			        </svg>
			    </div>
			    <div id="hostinger-feedback-survey"></div>
			    <div id="hts-questionsLeft">
			        <span id="hts-currentQuestion">1</span> Question of <span id="hts-allQuestions"></span>
			    </div>
			</div>
		HTML
		);

		$this->assertEquals( $expectedHtml, preg_replace( '/\s+/', '', $result ) );
	}

	/**
	 * @dataProvider getBetweenRuleValuesDataProvider
	 */
	public function testGetBetweenRuleValues( $inputRules, $expectedOutput ) {
		$output = $this->surveys->get_between_rule_values( $inputRules );
		$this->assertEquals( $expectedOutput, $output );
	}

	public function getBetweenRuleValuesDataProvider() {
		return [
			// Valid 'between' rule with numeric values
			[ [ 'between:10,20' ], [ '10', '20' ] ],
			// No 'between' rule
			[ [ 'min:5|max:15' ], [] ],
			// Invalid 'between' rule format (more than two values)
			[ [ 'between:30,40,50' ], [] ],
			// Invalid 'between' rule format (less than two values)
			[ [ 'between:25' ], [] ],
			// No 'between' rule among other rules
			[ [ 'other_rule:5,10' ], [] ],
		];
	}

}
