<?php

namespace Hostinger\Tests\Integration\Admin\Surveys;

use Hostinger\Tests\Integration\TestCase;
use Hostinger_Requests_Client;
use Hostinger_Surveys_Rest;

class HostingerSurveyClientTest extends TestCase {

	public function setUp(): void {
		parent::setUp();
		require_once HOSTINGER_ABSPATH . 'includes/requests/class-hostinger-requests-client.php';
		require_once HOSTINGER_ABSPATH . 'includes/surveys/Rest/class-hostinger-surveys-rest.php';
	}

	public function isClientEligibleMockResult( array $response ): bool {
		$clientMock = $this->createMock( Hostinger_Requests_Client::class );

		$clientMock->method( 'get' )->with( Hostinger_Surveys_Rest::CLIENT_SURVEY_ELIGIBILITY, [
			'identifier' => Hostinger_Surveys_Rest::CLIENT_SURVEY_IDENTIFIER,
		] )->willReturn( $response );

		$hostingerSurveysRest = new Hostinger_Surveys_Rest( $clientMock );
		$result               = $hostingerSurveysRest->is_client_eligible();

		return $result;
	}

	/**
	 * @dataProvider validDataProvider
	 */
	public function testIsClientEligibleReturnsTrue( array $response ): void {
		$result = $this->isClientEligibleMockResult( $response );
		$this->assertIsBool( $result );
		$this->assertTrue( $result );
	}

	public function validDataProvider(): array {
		$responseData = [
			'status'  => 200,
			'success' => true,
			'data'    => true,
			'error'   => null,
		];

		return [
			[
				'responseFalse' => [
					'headers'       => [],
					'body'          => json_encode( $responseData ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				],
			],
		];
	}

	/**
	 * @dataProvider invalidDataProvider
	 */
	public function testIsClientEligibleReturnsFalse( array $response ): void {
		$result = $this->isClientEligibleMockResult( $response );
		$this->assertFalse( $result );
	}

	public function invalidDataProvider(): array {
		$responseFalse = [
			'status'  => 200,
			'success' => true,
			'data'    => false,
			'error'   => null,
		];

		$response403 = [
			'status'  => 403,
			'success' => false,
			'data'    => null,
			'error'   => 'Forbidden',
		];

		return [
			[
				'responseFalse' => [
					'headers'       => [],
					'body'          => json_encode( $responseFalse ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				]
			],
			[
				'response403' => [
					'headers'       => [],
					'body'          => json_encode( $response403 ),
					'response'      => [
						'code'    => 403,
						'message' => 'Forbidden',
					],
					'cookies'       => [],
					'http_response' => null,
				]
			],
			[
				'responseDoesntProvided' => []
			]
		];
	}

	public function getSurveyQuestionsMockResult( array $expectedResponse ): array {
		$clientMock = $this->createMock( Hostinger_Requests_Client::class );

		$clientMock->method( 'get' )->with( Hostinger_Surveys_Rest::GET_SURVEY, [
			'identifier' => Hostinger_Surveys_Rest::CLIENT_SURVEY_IDENTIFIER,
		] )->willReturn( $expectedResponse );

		$hostingerSurveysRest = new Hostinger_Surveys_Rest( $clientMock );
		$result               = $hostingerSurveysRest->get_survey_questions();

		return $result;
	}

	/**
	 * @dataProvider getQuestionsDataProvider
	 */
	public function testSurveyResponseContainsScore( array $expectedResponse, bool $containsScore ): void {
		$result = $this->getSurveyQuestionsMockResult( $expectedResponse );
		$this->assertIsArray( $result );
		$this->assertArrayHasKey( 'slug', $result[0] );
		$this->assertEquals( 'score', $result[0]['slug'] );
	}

	/**
	 * @dataProvider getQuestionsDataProvider
	 */
	public function testSurveyResponseContainsComment( array $expectedResponse, bool $containsComment ): void {
		$result = $this->getSurveyQuestionsMockResult( $expectedResponse );
		$this->assertIsArray( $result );
		$this->assertArrayHasKey( 'slug', $result[1] );
		$this->assertEquals( 'comment', $result[1]['slug'] );
	}

	public function getQuestionsDataProvider(): array {
		$validResponse = [
			'status'  => 200,
			'success' => true,
			'data'    => [
				'identifier' => 'customer_satisfaction_score',
				'questions'  => [
					[ 'slug' => 'score', 'rules' => [ 'required', 'integer', 'between:1,10' ] ],
					[ 'slug' => 'comment', 'rules' => [ 'string', 'max:1000', 'not_regex:\/(http|https):\\\/\\\/\/' ] ],
					[ 'slug' => 'location', 'rules' => [ 'string', 'max:255' ] ],
					[ 'slug' => 'breadcrumbs', 'rules' => [ 'string' ] ],
					[ 'slug' => 'source', 'rules' => [ 'string' ] ],
					[ 'slug' => 'is_paid', 'rules' => [ 'boolean' ] ],
					[ 'slug' => 'no_hosting', 'rules' => [ 'boolean' ] ],
				],
			],
			'error'   => null,
		];

		$validResponse2 = [
			'status'  => 200,
			'success' => true,
			'data'    => [
				'identifier' => 'customer_satisfaction_score',
				'questions'  => [
					[ 'slug' => 'score', 'rules' => [ 'required', 'integer', 'between:1,10' ] ],
					[ 'slug' => 'comment', 'rules' => [ 'string', 'max:1000', 'not_regex:\/(http|https):\\\/\\\/\/' ] ],
					[ 'slug' => 'location', 'rules' => [ 'string', 'max:255' ] ],
					[ 'slug' => 'breadcrumbs', 'rules' => [ 'string' ] ],
					[ 'slug' => 'source', 'rules' => [ 'string' ] ],
					[ 'slug' => 'is_paid', 'rules' => [ 'boolean' ] ],
					[ 'slug' => 'no_hosting', 'rules' => [ 'boolean' ] ],
				],
			],
			'error'   => null,
		];

		return [
			[
				'validResponse' => [
					'headers'       => [],
					'body'          => json_encode( $validResponse ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				],
				true, // contains 'score'
			],
			[
				'validResponse2' => [
					'headers'       => [],
					'body'          => json_encode( $validResponse2 ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				],
				true, // contains 'comment'
			],
		];
	}


	/**
	 * @dataProvider getFalseQuestionsDataProvider
	 */
	public function testSurveyResponseIsEmpty( array $expectedResponse ): void {
		$result = $this->getSurveyQuestionsMockResult( $expectedResponse );
		$this->assertIsArray( $result );
		$this->assertEmpty( $result );
	}

	public function getFalseQuestionsDataProvider(): array {
		$emptyResponse = [
			'status'  => 200,
			'success' => true,
			'data'    => [],
			'error'   => null,
		];

		return [
			[
				'emptyResponse' => [
					'headers'       => [],
					'body'          => json_encode( $emptyResponse ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				],
			],
		];
	}

	/**
	 * @dataProvider validSubmitDataProvider
	 */
	public function testSubmitSurveyDataSuccess( array $response, array $data ): void {
		$clientMock = $this->createMock( Hostinger_Requests_Client::class );
		$clientMock->method( 'post' )->with( Hostinger_Surveys_Rest::SUBMIT_SURVEY, $data )->willReturn( $response );

		$hostingerSurveysRest = new Hostinger_Surveys_Rest( $clientMock );
		$result               = $hostingerSurveysRest->submit_survey_data( $data );

		$this->assertTrue( $result );
	}

	public function validSubmitDataProvider(): array {
		require_once HOSTINGER_ABSPATH . 'includes/surveys/Rest/class-hostinger-surveys-rest.php';

		$responseTrue = [
			'status'  => 200,
			'success' => true,
			'data'    => true,
			'error'   => null,
		];

		$data = [
			'identifier' => Hostinger_Surveys_Rest::CLIENT_SURVEY_IDENTIFIER,
			'answers'    => [
				[
					'question_slug' => 'location',
					'answer'        => 'wordpress_ai_onboarding',
				],
				[
					'question_slug' => 'score',
					'answer'        => 10,
				],
				[
					'question_slug' => 'comment',
					'answer'        => 'perfect',
				],
			],
		];

		return [
			[
				'responseTrue' => [
					'headers'       => [],
					'body'          => json_encode( $responseTrue ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				],
				'data'         => $data,
			],
		];
	}


	/**
	 * @dataProvider invalidSubmitDataProvider
	 */
	public function testSubmitSurveyDataFailure( array $response, array $data ): void {
		$clientMock = $this->createMock( Hostinger_Requests_Client::class );
		$clientMock->method( 'post' )->with( Hostinger_Surveys_Rest::SUBMIT_SURVEY, $data )->willReturn( $response );

		$hostingerSurveysRest = new Hostinger_Surveys_Rest( $clientMock );
		$result               = $hostingerSurveysRest->submit_survey_data( $data );

		$this->assertFalse( $result );
	}

	public function invalidSubmitDataProvider(): array {
		$responseFalse = [
			'status'  => 200,
			'success' => true,
			'data'    => false,
			'error'   => null,
		];

		$data = [
			'identifier' => Hostinger_Surveys_Rest::CLIENT_SURVEY_IDENTIFIER,
			'answers'    => [
				[
					'question_slug' => 'location',
					'answer'        => 'wordpress_ai_onboarding',
				],
				[
					'question_slug' => 'score',
					'answer'        => 10,
				],
				[
					'question_slug' => 'comment',
					'answer'        => 'perfect',
				],
			],
		];

		return [
			[
				'responseFalse' => [
					'headers'       => [],
					'body'          => json_encode( $responseFalse ),
					'response'      => [
						'code'    => 200,
						'message' => 'OK',
					],
					'cookies'       => [],
					'http_response' => null,
				],
				'data'          => $data,
			],
		];
	}


}