# Hostinger wordpress plugin

## CLI Commands

== Usage ==

Plugin allows enable/disable maintenance mode.
### Enable maintenance mode.
$ wp maintenance_mode 1
Success: Maintenance mode ENABLED
### Disable maintenance mode.
$ wp maintenance_mode 0
Success: Maintenance mode DISABLED

## Build Commands
### Install packages
$ npm install
### Compiling Assets
$ npm run prod
